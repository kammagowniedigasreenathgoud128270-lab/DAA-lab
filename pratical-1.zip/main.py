# Python Program for Insertion Sort

def insertion_sort(arr):
    # Traverse from the second element to the last
    for i in range(1, len(arr)):
        key = arr[i]          # Current element to be inserted
        j = i - 1

        # Move elements greater than key one position ahead
        while j >= 0 and arr[j] > key:
            arr[j + 1] = arr[j]
            j -= 1

        # Place the key in its correct position
        arr[j + 1] = key


# User Input
n = int(input("Enter the number of elements: "))

arr = []
print("Enter the elements:")
for i in range(n):
    arr.append(int(input()))

# Display Original Array
print("\nOriginal Array:")
print(arr)

# Sort the array
insertion_sort(arr)

# Display Sorted Array
print("\nSorted Array:")
print(arr)

# Time Complexity
print("\nTime Complexity of Insertion Sort:")
print("Best Case   : O(n)")
print("Average Case: O(n^2)")
print("Worst Case  : O(n^2)")
print("Space Complexity: O(1)")