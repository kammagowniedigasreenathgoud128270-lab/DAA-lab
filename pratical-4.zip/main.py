
import time

# Recursive Fibonacci function
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)


# Take input from user
n = int(input("Enter the value of n: "))

# Measure execution time
start_time = time.perf_counter()

result = fibonacci(n)

end_time = time.perf_counter()

# Calculate execution time
execution_time = end_time - start_time

# Display results
print("\nFibonacci value:", result)
print("Execution time:", execution_time, "seconds")
print("Time Complexity: O(2^n)")
print("Space Complexity: O(n)")

